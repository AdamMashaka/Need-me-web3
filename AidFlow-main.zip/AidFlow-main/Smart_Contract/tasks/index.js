
exports.getAddress = require("./get-address")
// exports.createNft0 = require("./FuchaNft/createNft0")
// exports.createNft1 = require("./FuchaNft/createNft1")
// exports.createNft2 = require("./FuchaNft/createNft2")
// exports.createNft3 = require("./FuchaNft/createNft3")